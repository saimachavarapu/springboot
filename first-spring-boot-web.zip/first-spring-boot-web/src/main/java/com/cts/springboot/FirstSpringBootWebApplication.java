package com.cts.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringBootWebApplication.class, args);
	}

}
